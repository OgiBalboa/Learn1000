import settings
settings.apply_settings()
settings.refresh()

print(settings.dict_db)