#*-*coding: utf-8 *-*

import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.screenmanager import ScreenManager,Screen
from kivy.properties import ObjectProperty,StringProperty
from kivy.uix.dropdown import DropDown
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.config import Config
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.spinner import Spinner
from database import database
from kivy.lang import Builder
from word_funcs import *
from threading import Thread
from quiz import quiz
from learn import learn
import user
import _bin.sounds.pronounces as pronounces
import platform
import settings
from language_pack import language_pack

#Window.size = (720,1230)
"""
if platform.system() == "Linux":
    Window.size = (720,1230)
"""
Window.clearcolor = (0, 0, 0.1, 1)
wordgroup = "basic"
udb = database("User-Database")
try:
    settings.refresh()
except Exception as e:
    print(e)
    settings.default_settings()
    settings.refresh()
class LoadScreen(Screen):
    user_name_ = ObjectProperty(None)
    learnlimit_ = ObjectProperty(None)
    dictionary_ = ObjectProperty(None)
    lgp = language_pack()
    class DropDown(DropDown):
        pass
    class DropDown2(DropDown):
        pass
    def load_conf(self,name,dbname,):
        settings.refresh()
        global db
        if dbname == "Almanca" or "German":
            dbname = "German"
        if name == "":
            return False
        settings.apply_settings(nm=name,)
        db = database(dbname.capitalize()+"-"+settings.language)
        return True
    def set_lang(self,lang):
        settings.apply_settings(lang=lang)
        for i in self.walk():
            try : 
                i.text = language_pack().text(i.text)
            except :
                pass
    def set_dict(self,lang):
        settings.apply_settings(dict="German")
    def set_learnlimit(self,param):
        if param == "az":
            settings.apply_settings(lm = 5)
        if param == "orta":
            settings.apply_settings(lm = 10)
        if param == "cok":
            settings.apply_settings(lm = 20)
class HelloScreen(Screen):
    def hello_(self):
        if settings.dictionary == "none":
            return False
        else :
            global db
            settings.refresh()
            db = database(settings.dictionary.capitalize()+"-"+settings.language.capitalize())
            return True
class MainMenu(Screen):
    user_info = ObjectProperty(None)
    scr = ObjectProperty(None)
    user_infos = " "*45 + language_pack().text("Hoş Geldin ") + str(settings.user_name) + "!\n\n"
    user_infos += " "*45 +language_pack().text("İlerleme Durumunuz\n")
    user_infos +="Kelime Grupları : Temel     |   Yaygın  |   Nadir   |   İleri   |   GENEL  \n"+ " "*32
    def on_pre_enter(self, *args):
        for i in self.walk():
            try:
                i.text = language_pack().text(i.text)
            except:
                pass
        self.scr.text = str(Window.size)
    for i in udb.fetchall("progress"):
        user_infos += "%"+str(int(i[0])) +" "*12 + "%"+ str(int(i[1])) + " "*8 + "%"+ str(int(i[2])) + " "*10 +"%"+  str(int(i[3])) + " "*8 + "%"+str(int(i[4])) + " "*2

    def upd(self):
        settings.refresh()
        user.cal_progress(udb=udb)
        self.user_info.text = " " * 45 + language_pack().text("Hoş Geldin ") + str(settings.user_name) + "! \n\n"

        self.user_info.text  +=" " * 45 + language_pack().text("İlerleme Durumunuz \n")
        self.user_info.text  += language_pack().text("Kelime Grupları : Temel     |   Yaygın  |   Nadir   |   İleri   |   GENEL  \n" + " " * 32)
        for i in udb.fetchall("progress"):
            self.user_info.text  += "%" + str(int(i[0])) + " " * 16 + "%" + str(int(i[1])) + " " * 12 + "%" + str(int(i[2])) + " " * 10 + "%" + str(int(i[3])) + " " * 12 + "%" + str(int(i[4])) + " " * 2

    global Quiz_Select
    class Quiz_Select(GridLayout):
        lgp = language_pack()
        def auto(self):
            global wordgroup
            wordgroup = "auto"
            popupWindow.dismiss()
        def basic(self):
            global wordgroup
            wordgroup = "basic"
            popupWindow.dismiss()
        def common(self):
            global wordgroup
            wordgroup = "common"
            popupWindow.dismiss()
        def rare(self):
            global wordgroup
            wordgroup = "rare"
            popupWindow.dismiss()
        def advantage(self):
            global wordgroup
            wordgroup = "advantage"
            popupWindow.dismiss()
            
    def quiz_difficulty(self):
        global popupWindow
        show = Quiz_Select()
        popupWindow = Popup(title = language_pack().text("Quiz zorluğu seçiniz"),content = show)
        popupWindow.open()

class Learn(Screen):
    word      = ObjectProperty(None)
    sentence  = ObjectProperty(None)
    pronounce = ObjectProperty(None)
    translate = ObjectProperty(None)
    _word_    = ObjectProperty(None)
    _tr_      = ObjectProperty(None)

    def on_pre_enter(self, *args):
        self._word_.text = language_pack().text("Başlamak için Next'e basınız")
        self._tr_.text = ""
        for i in self.walk():
            for i in self.walk():
                try:
                    i.text = language_pack().text(i.text)
                except:
                    pass
    def next_(self):
        self._word_.text = language_pack().text("Kelime : ")
        self._tr_.text = language_pack().text("Çevirisi : ")
        if self.word.text == "":
            global l
            l = learn(db = db,udb = udb) # Eğer kelime yoksa kelime havuzu oluştur.
        if l.rowid <= len(l.wordlist)-1: # kelimeler bitene kadar öğret
            self.word.text,self.translate.text,self.table = l.next_()
        else :
            self._word_.text =language_pack().text("KELİMELER BİTTİ")
            self.word.text = ""
            self.translate.text = ""
            self._tr_.text =language_pack().text("Şimdi Quiz yap ve tekrar buraya gel")
    def click(self):
        pronounces.play()

    def reset(self):
        global l
        l = None
        self.word.text = ""
        self.translate.text = ""

class Quiz(Screen):
    query = ObjectProperty(None)
    answer = ObjectProperty(None)
    info = ObjectProperty(None)
    global start
    start = ObjectProperty(None)
    quizlayout = ObjectProperty(None)

    def on_pre_enter(self,value=None):
        for i in self.walk():
            for i in self.walk():
                try:
                    i.text = language_pack().text(i.text)
                except:
                    pass
    def ok(self,value = None):
        global q
        if self.query.text == "":
            q = quiz(db = db,udb = udb,wordgroup = wordgroup)
        else:
            q.pressed(Capital(self.answer.text))
        self.query.text = q.query
        self.info.text = q.info
        q.ans = ""
        if q.query == "":
            self.query.text = language_pack().text(" KELİMELER BİTTİ !\n Yeni kelimeler öğren ve tekrar buraya gel !")
        #self.answer.text = ""
    def reset(self):
        global q
        q = None
        self.info.text = language_pack().text("Hoş Geldiniz\nBaşlamak için 'Onayla' butonuna basınız")
        self.query.text = ""
class Settings_(Screen):
    global ConfirmReset
    lgp = language_pack()
    learnlimit_ = ObjectProperty(None)
    class DropDown(DropDown):
        pass
    def on_pre_enter(self,value=None):
        for i in self.walk():
            for i in self.walk():
                try:
                    i.text = language_pack().text(i.text)
                except:
                    pass
    class ConfirmReset(GridLayout):
        lgp = language_pack()
        def reset_db_ok(self):
            udb.reset()
            confirmreset.dismiss()
        def reset_db_cancel(self):
            confirmreset.dismiss()
    def set_lang(self,langg):
        settings.apply_settings(lang=langg)
        settings.refresh()
    def reset_db(self):
        global ConfirmReset
        global confirmreset
        show = ConfirmReset()
        confirmreset = Popup(title = language_pack().text("TÜM BİLGİLERİNİN SIFIRLANACAK !"),content = show)
        confirmreset.open()

class Knowns(Screen):
    info =         ObjectProperty(None)
    known_words  = ObjectProperty(None)
    known_fcount = ObjectProperty(None)
    known_tcount = ObjectProperty(None)
    known_prg    = ObjectProperty(None)
    known_pc     = ObjectProperty(None)
    layout_content=ObjectProperty(None)
    def show(self,param = None):
        if param == None:
            known_basic  = udb.fetchall("basic")
            known_common = udb.fetchall("common")
            known_rare   = udb.fetchall("rare")
            known_advantage = udb.fetchall("advantage")
            known_all = known_basic + known_common + known_rare + known_advantage
        elif param == "basic":
            known_all = udb.fetchall("basic")
        elif param == "common":
            known_all = udb.fetchall("common")
        elif param == "rare":
            known_all = udb.fetchall("rare")
        elif param == "advantage":
            known_all = udb.fetchall("advantage")
        self.layout_content.bind(minimum_height=self.layout_content.setter('height'))
        self.info.text = language_pack().text("Öğrendiğiniz kelime sayısı : ") + str(len(known_all))
        self.known_words.text = ""
        self.known_tcount.text = ""
        self.known_fcount.text = ""
        self.known_prg.text = ""
        self.known_pc.text = ""
        if len(known_all) > 0:
            for w in known_all:
                self.known_words.text += "\n  " +  str(w[5]) + "\n "
                self.known_tcount.text+= "\n " +  str(w[2]) + "\n "
                self.known_fcount.text+= "\n " +  str(w[3]) + "\n"
                self.known_prg.text   += "\n " +  str(w[1]) + "\n"
                self.known_pc.text    += "\n %" +  str(int(w[4])) + "\n"

class WindowManager (ScreenManager):
    pass
kv = Builder.load_file("mainmenu.kv")

class LernenApp(App):
    def build(self):
        return kv
    def on_start(self):
        pass
if __name__ == "__main__":
    LernenApp().run()
