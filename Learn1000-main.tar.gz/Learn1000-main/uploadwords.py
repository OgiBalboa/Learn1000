import sqlite3
name = "German-Turkish"
with sqlite3.connect("_bin/dictionary/"+ str(name)+".db") as db:
    cur = db.cursor()
    table = "advanced"
    vals = []
    counter = 1
    with open("wrods.txt", "r") as file:
        for i in range (750,1001):
            a = file.readlines()[i]
            b = a.split("\t")
            word = "".join(b[1]).capitalize()
            c = b[2].split("\n")
            tr = "".join(c[0]).capitalize()
            vals.append(word)
            vals.append(tr)
            vals.append(counter)
            try:
                exe = "INSERT INTO " + table + " (Word,Translation,Word_ID) VALUES (?,?,?);"
                cur.execute(exe,vals)
                counter += 1
                vals = []
            except:
                vals = []
            file.seek(0)
            if counter == 251:
                print(" TAMAMLANDI ")
                break

        db.commit()