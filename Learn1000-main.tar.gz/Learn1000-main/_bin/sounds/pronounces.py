from kivy.core.audio import SoundLoader
def play ():
    try:
        sound = SoundLoader.load('_bin/sounds/schlafen.wav')
        if sound:
            sound.play()
    except Exception as e:
        print(e)
